import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  X,
  QrCode,
  Copy,
  Check,
  Share2,
  ExternalLink,
  MessageCircle,
  Send,
} from 'lucide-react';

interface UpiQrModalProps {
  isOpen: boolean;
  onClose: () => void;
  calculatedAmount: string; // From calculator display
}

const STORAGE_VPA_KEY = 'upi_calculator_vpa_address';
const STORAGE_PAYEE_KEY = 'upi_calculator_payee_name';
const STORAGE_NOTE_KEY = 'upi_calculator_note';
const FIXED_VPA = '9429032801@okbizaxis';
const DEFAULT_PAYEE = 'Merchant';
const DEFAULT_NOTE = 'grocery';

export const UpiQrModal: React.FC<UpiQrModalProps> = ({
  isOpen,
  onClose,
  calculatedAmount,
}) => {
  const [vpa] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_VPA_KEY);
    if (!saved || saved === 'merchant@upi') {
      try {
        localStorage.setItem(STORAGE_VPA_KEY, FIXED_VPA);
      } catch {
        // ignore
      }
      return FIXED_VPA;
    }
    return saved;
  });

  const [payeeName] = useState<string>(() => {
    return localStorage.getItem(STORAGE_PAYEE_KEY) || DEFAULT_PAYEE;
  });

  const [note] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_NOTE_KEY);
    if (!saved || saved === 'Payment via Calculator') {
      try {
        localStorage.setItem(STORAGE_NOTE_KEY, DEFAULT_NOTE);
      } catch {
        // ignore
      }
      return DEFAULT_NOTE;
    }
    return saved || DEFAULT_NOTE;
  });

  const [amount, setAmount] = useState<string>('');
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Sync amount from calculator display when opened
  useEffect(() => {
    if (isOpen) {
      const cleaned = calculatedAmount.replace(/,/g, '').trim();
      const num = parseFloat(cleaned);
      if (!isNaN(num) && num > 0) {
        setAmount(num.toFixed(2));
      } else {
        setAmount('');
      }
    }
  }, [isOpen, calculatedAmount]);

  // Construct official UPI URI with fixed VPA and description "grocery"
  const upiUri = React.useMemo(() => {
    const trimmedVpa = (vpa || FIXED_VPA).trim();
    if (!trimmedVpa) return '';

    const params = new URLSearchParams();
    params.append('pa', trimmedVpa);
    if (payeeName.trim()) params.append('pn', payeeName.trim());
    if (amount.trim() && !isNaN(parseFloat(amount)) && parseFloat(amount) > 0) {
      params.append('am', parseFloat(amount).toFixed(2));
    }
    params.append('cu', 'INR');
    params.append('tn', note.trim() || DEFAULT_NOTE);

    return `upi://pay?${params.toString()}`;
  }, [vpa, payeeName, amount, note]);

  // Generate full QR Code when upiUri changes
  useEffect(() => {
    if (!isOpen || !upiUri) return;

    QRCode.toDataURL(upiUri, {
      width: 400,
      margin: 2,
      color: {
        dark: '#111827',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        setQrDataUrl(url);
      })
      .catch((err) => {
        console.error('Failed to generate QR code', err);
      });
  }, [isOpen, upiUri]);

  // Copy UPI payment URI link
  const handleCopyLink = () => {
    if (!upiUri) return;
    navigator.clipboard.writeText(upiUri);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Share using Web Share API
  const handleShare = async () => {
    if (!upiUri) return;
    const amtDisplay = amount && parseFloat(amount) > 0 ? `₹${parseFloat(amount).toFixed(2)}` : '';
    if (navigator.share) {
      try {
        await navigator.share({
          title: `UPI Payment Request: ${amtDisplay || 'grocery'}`,
          text: `Pay ${amtDisplay ? `${amtDisplay} ` : ''}for ${note || 'grocery'} via UPI (${vpa})`,
          url: upiUri,
        });
      } catch {
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  // WhatsApp share message
  const whatsappShareText = React.useMemo(() => {
    if (!upiUri) return '';
    const amtDisplay = amount && parseFloat(amount) > 0 ? `₹${parseFloat(amount).toFixed(2)}` : '';
    const lines = [
      `*UPI Payment Request*`,
      amtDisplay ? `Amount: *${amtDisplay}*` : '',
      `Note: *${note || 'grocery'}*`,
      `UPI ID: ${vpa}`,
      ``,
      `Tap to pay directly:`,
      upiUri,
    ].filter(Boolean);
    return lines.join('\n');
  }, [upiUri, amount, note, vpa]);

  const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(whatsappShareText)}`;

  if (!isOpen) return null;

  return (
    <div
      id="upi-qr-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="upi-qr-modal-container"
        className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[94vh]"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-700 px-5 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/15 backdrop-blur-xs flex items-center justify-center">
              <QrCode className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-tight leading-tight">
                UPI Payment QR
              </h2>
              <p className="text-[11px] text-emerald-100/90 font-medium">
                Scan &amp; Pay via any UPI App
              </p>
            </div>
          </div>
          <button
            id="upi-modal-close-btn"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-black/10 hover:bg-black/20 flex items-center justify-center text-white transition-colors"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body: Amount above, Full QR Code, and Send Options */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col items-center gap-3.5 text-stone-800">
          {/* Amount Display directly above QR Code */}
          <div
            id="upi-amount-above-qr"
            className="w-full bg-stone-50 border border-stone-200/90 rounded-2xl px-4 py-3 flex items-center justify-between shadow-2xs"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                ₹
              </div>
              <div className="flex flex-col">
                <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                  Payment Amount
                </span>
                <span className="text-xs font-medium text-emerald-800">
                  grocery
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-stone-400 font-bold text-xl">₹</span>
              <input
                id="upi-amount-input"
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-28 text-right font-extrabold text-2xl text-stone-900 bg-transparent border-b border-transparent focus:border-emerald-600 focus:outline-none tracking-tight"
              />
            </div>
          </div>

          {/* Full QR Code Display */}
          <div
            id="full-qr-code-wrapper"
            className="w-full bg-white rounded-2xl border border-stone-200 shadow-sm p-4 flex flex-col items-center justify-center"
          >
            {qrDataUrl ? (
              <img
                id="full-qr-code-image"
                src={qrDataUrl}
                alt="UPI Payment QR Code"
                className="w-64 h-64 sm:w-72 sm:h-72 object-contain rounded-lg"
              />
            ) : (
              <div className="w-64 h-64 flex items-center justify-center text-stone-400 text-sm">
                Generating QR Code...
              </div>
            )}

            {/* Supported UPI Apps strip */}
            <div className="mt-3 pt-2.5 border-t border-stone-100 w-full flex items-center justify-center gap-2 text-[10px] font-semibold text-stone-500 uppercase tracking-wider">
              <span>GPay</span>
              <span>•</span>
              <span>PhonePe</span>
              <span>•</span>
              <span>Paytm</span>
              <span>•</span>
              <span>BHIM</span>
              <span>•</span>
              <span>Cred</span>
            </div>
          </div>

          {/* Send Options Section */}
          <div id="upi-send-options-container" className="w-full flex flex-col gap-2">
            <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider px-1">
              Send Options
            </div>

            {/* Send Option 1: Send via WhatsApp */}
            <a
              id="upi-send-whatsapp-btn"
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-medium text-xs flex items-center justify-center gap-2 shadow-sm transition-all text-center"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Send via WhatsApp</span>
            </a>

            {/* Send Option 2 & 3: Share and Copy Link */}
            <div className="grid grid-cols-2 gap-2">
              <button
                id="upi-send-share-btn"
                type="button"
                onClick={handleShare}
                className="py-2.5 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 active:scale-[0.99] text-stone-800 font-medium text-xs flex items-center justify-center gap-1.5 transition-all border border-stone-200"
              >
                <Share2 className="w-3.5 h-3.5 text-stone-600" />
                <span>Send / Share</span>
              </button>

              <button
                id="upi-send-copy-btn"
                type="button"
                onClick={handleCopyLink}
                className="py-2.5 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 active:scale-[0.99] text-stone-800 font-medium text-xs flex items-center justify-center gap-1.5 transition-all border border-stone-200"
              >
                {copiedLink ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-stone-600" />
                )}
                <span>{copiedLink ? 'Link Copied!' : 'Copy Link'}</span>
              </button>
            </div>

            {/* Send Option 4: Open in UPI App */}
            <a
              id="upi-send-app-direct-btn"
              href={upiUri}
              className="w-full py-2 px-3 rounded-xl bg-stone-50 hover:bg-stone-100 text-stone-700 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors border border-stone-200/80 text-center"
            >
              <ExternalLink className="w-3.5 h-3.5 text-stone-500" />
              <span>Open in UPI App (GPay / PhonePe / Paytm)</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
